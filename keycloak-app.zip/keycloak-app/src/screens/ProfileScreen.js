import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import { useAuth } from '../context/AuthContext';

const ProfileScreen = () => {
  const { user, logout } = useAuth();

  if (!user) {
    return (
      <View style={styles.container}>
        <Text style={styles.noUserText}>No hay información de usuario disponible</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
      <View style={styles.header}>
        <Text style={styles.title}>Perfil de Usuario</Text>
        <Text style={styles.welcomeText}>Bienvenido</Text>
      </View>
      
      {/* Información Básica */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Información Básica</Text>
        
        <View style={styles.infoContainer}>
          <Text style={styles.label}>Usuario:</Text>
          <Text style={styles.value}>{user.username || user.preferred_username || 'No disponible'}</Text>
        </View>

        <View style={styles.infoContainer}>
          <Text style={styles.label}>Nombre completo:</Text>
          <Text style={styles.value}>
            {user.firstName && user.lastName 
              ? `${user.firstName} ${user.lastName}`
              : user.name || 'No disponible'
            }
          </Text>
        </View>

        <View style={styles.infoContainer}>
          <Text style={styles.label}>Correo electrónico:</Text>
          <Text style={styles.value}>{user.email || 'No disponible'}</Text>
        </View>
      </View>

      {/* Atributos Personalizados - CRÍTICOS */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Información de Contacto</Text>
        
        <View style={styles.infoContainer}>
          <Text style={styles.label}>Teléfono:</Text>
          <Text style={styles.value}>
            {user.telefono || user.phone_number || 'No disponible'}
          </Text>
        </View>

        <View style={styles.infoContainer}>
          <Text style={styles.label}>Dirección:</Text>
          <Text style={styles.value}>
            {user.direccion || user.address?.formatted || 'No disponible'}
          </Text>
        </View>
      </View>

      <TouchableOpacity style={styles.logoutButton} onPress={logout}>
        <Text style={styles.logoutText}>Cerrar Sesión</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  contentContainer: {
    padding: 20,
  },
  header: {
    alignItems: 'center',
    marginBottom: 30,
    marginTop: 20,
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 8,
  },
  welcomeText: {
    fontSize: 16,
    color: '#666',
  },
  noUserText: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginTop: 50,
  },
  section: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 4,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
    color: '#007AFF',
    borderBottomWidth: 2,
    borderBottomColor: '#f0f0f0',
    paddingBottom: 8,
  },
  infoContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f8f8f8',
  },
  label: {
    fontSize: 15,
    fontWeight: '600',
    color: '#555',
    flex: 1,
  },
  value: {
    fontSize: 15,
    color: '#333',
    flex: 2,
    textAlign: 'right',
  },
  logoutButton: {
    backgroundColor: '#FF3B30',
    padding: 18,
    borderRadius: 16,
    alignItems: 'center',
    marginTop: 10,
    marginBottom: 30,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 5,
  },
  logoutText: {
    color: 'white',
    fontSize: 17,
    fontWeight: 'bold',
  },
});

export default ProfileScreen;