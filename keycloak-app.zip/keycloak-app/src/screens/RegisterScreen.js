import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ScrollView,
} from 'react-native';

const RegisterScreen = ({ navigation }) => {
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    firstName: '',
    lastName: '',
    password: '',
    confirmPassword: '',
    direccion: '',
    telefono: '',
  });

  const handleRegister = () => {
    // Validaciones básicas
    if (!formData.username || !formData.email || !formData.password) {
      Alert.alert('Error', 'Por favor completa los campos obligatorios');
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      Alert.alert('Error', 'Las contraseñas no coinciden');
      return;
    }

    // Aquí implementarías el registro con Keycloak
    Alert.alert(
      'Registro', 
      'Funcionalidad de registro pendiente. Por ahora crea el usuario directamente en Keycloak Admin.',
      [{ text: 'OK', onPress: () => navigation.navigate('Login') }]
    );
  };

  const updateFormData = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.content}>
        <Text style={styles.title}>Crear Cuenta</Text>
        <Text style={styles.subtitle}>Registro en Realm Test</Text>
        
        <TextInput
          style={styles.input}
          placeholder="Usuario *"
          value={formData.username}
          onChangeText={(value) => updateFormData('username', value)}
          autoCapitalize="none"
          placeholderTextColor="#999"
        />
        
        <TextInput
          style={styles.input}
          placeholder="Correo electrónico *"
          value={formData.email}
          onChangeText={(value) => updateFormData('email', value)}
          keyboardType="email-address"
          autoCapitalize="none"
          placeholderTextColor="#999"
        />
        
        <TextInput
          style={styles.input}
          placeholder="Nombre"
          value={formData.firstName}
          onChangeText={(value) => updateFormData('firstName', value)}
          placeholderTextColor="#999"
        />
        
        <TextInput
          style={styles.input}
          placeholder="Apellido"
          value={formData.lastName}
          onChangeText={(value) => updateFormData('lastName', value)}
          placeholderTextColor="#999"
        />

        <TextInput
          style={styles.input}
          placeholder="Teléfono"
          value={formData.telefono}
          onChangeText={(value) => updateFormData('telefono', value)}
          keyboardType="phone-pad"
          placeholderTextColor="#999"
        />

        <TextInput
          style={styles.input}
          placeholder="Dirección"
          value={formData.direccion}
          onChangeText={(value) => updateFormData('direccion', value)}
          placeholderTextColor="#999"
        />
        
        <TextInput
          style={styles.input}
          placeholder="Contraseña *"
          value={formData.password}
          onChangeText={(value) => updateFormData('password', value)}
          secureTextEntry
          placeholderTextColor="#999"
        />
        
        <TextInput
          style={styles.input}
          placeholder="Confirmar contraseña *"
          value={formData.confirmPassword}
          onChangeText={(value) => updateFormData('confirmPassword', value)}
          secureTextEntry
          placeholderTextColor="#999"
        />
        
        <TouchableOpacity style={styles.button} onPress={handleRegister}>
          <Text style={styles.buttonText}>Registrarse</Text>
        </TouchableOpacity>

        <TouchableOpacity 
          style={styles.loginButton}
          onPress={() => navigation.navigate('Login')}
        >
          <Text style={styles.loginText}>¿Ya tienes cuenta? Inicia sesión</Text>
        </TouchableOpacity>

        <Text style={styles.note}>
          * Campos obligatorios{'\n'}
          Nota: El registro completo requiere configuración en Keycloak Admin
        </Text>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  content: {
    padding: 20,
    paddingTop: 40,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 8,
    color: '#333',
  },
  subtitle: {
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 40,
    color: '#666',
  },
  input: {
    backgroundColor: 'white',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#ddd',
    fontSize: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
  },
  button: {
    backgroundColor: '#34C759',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 8,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 3,
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  loginButton: {
    alignItems: 'center',
    padding: 12,
    marginBottom: 20,
  },
  loginText: {
    color: '#007AFF',
    fontSize: 15,
    fontWeight: '500',
  },
  note: {
    fontSize: 12,
    color: '#888',
    textAlign: 'center',
    lineHeight: 16,
    fontStyle: 'italic',
  },
});

export default RegisterScreen;