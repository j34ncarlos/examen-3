import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { useAuth } from '../context/AuthContext';
import LoginScreen from './LoginScreen';
import RegisterScreen from './RegisterScreen';
import ProfileScreen from './ProfileScreen';

const Stack = createStackNavigator();

const HomeScreen = () => {
  const { isAuthenticated } = useAuth();

  return (
    <NavigationContainer>
      <Stack.Navigator>
        {isAuthenticated ? (
          // Usuario autenticado - va directo al perfil
          <Stack.Screen 
            name="Profile" 
            component={ProfileScreen}
            options={{ 
              title: 'Mi Perfil',
              headerStyle: {
                backgroundColor: '#007AFF',
              },
              headerTintColor: 'white',
              headerTitleStyle: {
                fontWeight: 'bold',
              }
            }}
          />
        ) : (
          // Usuario no autenticado
          <>
            <Stack.Screen 
              name="Login" 
              component={LoginScreen}
              options={{ headerShown: false }}
            />
            <Stack.Screen 
              name="Register" 
              component={RegisterScreen}
              options={{ 
                title: 'Registro',
                headerStyle: {
                  backgroundColor: '#f8f9fa',
                },
                headerTintColor: '#007AFF',
              }}
            />
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default HomeScreen;