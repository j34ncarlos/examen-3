import React, { createContext, useState, useContext } from 'react';
import axios from 'axios';

const AuthContext = createContext();

export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(false);

  const keycloakConfig = {
    realm: 'pruebas',
    clientId: 'react-native-app',
    // <-- client secret REAL que confirmaste
    clientSecret: '1erlQv4JETceuA1Zrk1duM9wwXPcUssn',
    authUrl: 'http://192.168.0.102:8080/realms/pruebas/protocol/openid-connect',
    adminUrl: 'http://192.168.0.102:8080/admin/realms/pruebas'
  };

  // login
  const login = async (username, password) => {
    setLoading(true);
    try {
      console.log('Iniciando login con:', username);

      const params = new URLSearchParams();
      params.append('grant_type', 'password');
      params.append('client_id', keycloakConfig.clientId);
      params.append('client_secret', keycloakConfig.clientSecret);
      params.append('username', username);
      params.append('password', password);
      params.append('scope', 'openid profile email');

      // Enviamos como application/x-www-form-urlencoded (usar toString())
      const tokenResponse = await axios.post(
        `${keycloakConfig.authUrl}/token`,
        params.toString(),
        {
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
          },
          timeout: 10000,
        }
      );

      const { access_token } = tokenResponse.data;
      console.log('Token obtenido correctamente');

      const userInfo = await axios.get(
        `${keycloakConfig.authUrl}/userinfo`,
        {
          headers: {
            Authorization: `Bearer ${access_token}`,
          },
        }
      );

      const userData = {
        ...userInfo.data,
        username: userInfo.data.preferred_username || username,
        firstName: userInfo.data.given_name || '',
        lastName: userInfo.data.family_name || '',
        email: userInfo.data.email || '',
        direccion: 'No disponible',
        telefono: 'No disponible',
      };

      setUser(userData);
      setIsAuthenticated(true);
      console.log('Login exitoso');
      return { success: true };

    } catch (error) {
      console.error('Error de login:', error.response?.data || error.message);

      let errorMessage = 'Error de conexión';
      if (error.response?.data) {
        const errorData = error.response.data;
        if (errorData.error === 'unauthorized_client') {
          errorMessage = 'Cliente no autorizado. Verifica la configuración en Keycloak.';
        } else if (errorData.error === 'invalid_grant') {
          errorMessage = 'Credenciales inválidas';
        } else {
          errorMessage = errorData.error_description || 'Error desconocido';
        }
      }

      return { success: false, error: errorMessage };
    } finally {
      setLoading(false);
    }
  };

  // register (usa credenciales admin para crear usuario en el realm)
  const register = async (userData) => {
    setLoading(true);
    try {
      console.log('Registrando usuario:', userData.username);

      // 1) Obtener token admin usando las credenciales que confirmaste (solo para pruebas)
      const adminParams = new URLSearchParams();
      adminParams.append('grant_type', 'password');
      adminParams.append('client_id', keycloakConfig.clientId);
      adminParams.append('client_secret', keycloakConfig.clientSecret);
      // Credenciales admin que me diste (asegúrate que existan y estén en el realm "pruebas")
      adminParams.append('username', 'admin');
      adminParams.append('password', 'admin123');

      const adminTokenResponse = await axios.post(
  `${keycloakConfig.authUrl}/token`,
  new URLSearchParams({
    grant_type: 'password',
    client_id: keycloakConfig.clientId,
    client_secret: keycloakConfig.clientSecret,
    username: 'appadmin',
    password: 'pol123',
  }),
  {
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    timeout: 10000,
  }
);


      const adminToken = adminTokenResponse.data.access_token;
      console.log('Token de administrador obtenido');

      // 2) Crear usuario
      const userPayload = {
        username: userData.username,
        email: userData.email,
        firstName: userData.firstName,
        lastName: userData.lastName,
        enabled: true,
        emailVerified: false,
        credentials: [
          {
            type: 'password',
            value: userData.password,
            temporary: false,
          },
        ],
      };

      // atributos opcionales
      const attributes = {};
      if (userData.telefono) attributes.telefono = [userData.telefono];
      if (userData.direccion) attributes.direccion = [userData.direccion];
      if (Object.keys(attributes).length) userPayload.attributes = attributes;

      console.log('Creando usuario con payload:', userPayload);

      const createUserResponse = await axios.post(
        `${keycloakConfig.adminUrl}/users`,
        userPayload,
        {
          headers: {
            Authorization: `Bearer ${adminToken}`,
            'Content-Type': 'application/json',
          },
          timeout: 10000,
        }
      );

      // Keycloak responde 201 Created (Location header con ID)
      console.log('Usuario creado. status:', createUserResponse.status);

      // Buscar ID del usuario recién creado (por username)
      const searchResponse = await axios.get(
        `${keycloakConfig.adminUrl}/users?username=${encodeURIComponent(userData.username)}`,
        {
          headers: { Authorization: `Bearer ${adminToken}` },
        }
      );

      if (searchResponse.data && searchResponse.data.length > 0) {
        const userId = searchResponse.data[0].id;
        console.log('ID del usuario creado:', userId);

        // Intentar enviar email de verificación (si está configurado)
        try {
          await axios.put(
            `${keycloakConfig.adminUrl}/users/${userId}/send-verify-email`,
            {},
            { headers: { Authorization: `Bearer ${adminToken}` } }
          );
          console.log('Email de verificación solicitado');
        } catch (emailErr) {
          console.log('No se pudo solicitar email de verificación:', emailErr.message);
        }
      }

      return {
        success: true,
        message: 'Usuario registrado exitosamente. Ahora puedes iniciar sesión.',
      };

    } catch (error) {
      console.error('Error en registro:', error.response?.data || error.message);
      let errorMessage = 'Error al registrar usuario';

      if (error.response?.data) {
        if (error.response.status === 409) {
          errorMessage = 'El usuario ya existe. Por favor usa otro nombre de usuario.';
        } else if (error.response.status === 401) {
          errorMessage = 'Error de autenticación de administrador. Verifica las credenciales.';
        } else if (error.response.status === 403) {
          errorMessage = 'Permisos insuficientes. El usuario admin no tiene permisos para crear usuarios.';
        } else {
          // intentar extraer mensaje específico
          const d = error.response.data;
          errorMessage = d.errorMessage || d.error || JSON.stringify(d);
        }
      } else if (error.code === 'ECONNABORTED') {
        errorMessage = 'Timeout - El servidor no respondió a tiempo';
      } else if (error.message && error.message.includes('Network Error')) {
        errorMessage = 'Error de red - Verifica que Keycloak esté ejecutándose';
      }

      return { success: false, error: errorMessage };
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
    setIsAuthenticated(false);
  };

  const value = {
    user,
    isAuthenticated,
    loading,
    login,
    register,
    logout,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};
