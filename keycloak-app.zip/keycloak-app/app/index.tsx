import { Redirect } from 'expo-router';
import { useAuth } from '../src/context/AuthContext';

export default function Index() {
  const { isAuthenticated } = useAuth();

  // Redirigir basado en el estado de autenticación
  if (isAuthenticated) {
    return <Redirect href={"/(tabs)" as any} />;
  } else {
    return <Redirect href={"/login" as any} />;
  }
}