import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ScrollView,
  ActivityIndicator,
} from 'react-native';
import { router } from 'expo-router';
import { useAuth } from '../src/context/AuthContext';

interface FormData {
  username: string;
  email: string;
  firstName: string;
  lastName: string;
  password: string;
  confirmPassword: string;
  direccion: string;
  telefono: string;
}

export default function RegisterScreen() {
  const [formData, setFormData] = useState<FormData>({
    username: '',
    email: '',
    firstName: '',
    lastName: '',
    password: '',
    confirmPassword: '',
    direccion: '',
    telefono: '',
  });

  const { register, loading } = useAuth();

  const handleRegister = async () => {
    // Validaciones
    if (!formData.username || !formData.email || !formData.password) {
      Alert.alert('Error', 'Por favor completa los campos obligatorios (*)');
      return;
    }

    if (formData.password.length < 6) {
      Alert.alert('Error', 'La contraseña debe tener al menos 6 caracteres');
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      Alert.alert('Error', 'Las contraseñas no coinciden');
      return;
    }

    if (!formData.email.includes('@')) {
      Alert.alert('Error', 'Por favor ingresa un email válido');
      return;
    }

    console.log('Enviando datos de registro:', formData);
    
    const result = await register(formData);
    
    if (result.success) {
      Alert.alert(
        'Registro Exitoso', 
        result.message,
        [
          { 
            text: 'OK', 
            onPress: () => router.push("/login" as any) 
          }
        ]
      );
    } else {
      Alert.alert('Error en Registro', result.error);
    }
  };

  const updateFormData = (field: keyof FormData, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.content}>
        <Text style={styles.title}>Crear Cuenta</Text>
        <Text style={styles.subtitle}>Keycloak Realm: pruebas</Text>
        
        <Text style={styles.requiredNote}>* Campos obligatorios</Text>
        
        <TextInput
          style={styles.input}
          placeholder="Usuario *"
          value={formData.username}
          onChangeText={(value) => updateFormData('username', value)}
          autoCapitalize="none"
          editable={!loading}
        />
        
        <TextInput
          style={styles.input}
          placeholder="Correo electrónico *"
          value={formData.email}
          onChangeText={(value) => updateFormData('email', value)}
          keyboardType="email-address"
          autoCapitalize="none"
          editable={!loading}
        />
        
        <TextInput
          style={styles.input}
          placeholder="Nombre"
          value={formData.firstName}
          onChangeText={(value) => updateFormData('firstName', value)}
          editable={!loading}
        />
        
        <TextInput
          style={styles.input}
          placeholder="Apellido"
          value={formData.lastName}
          onChangeText={(value) => updateFormData('lastName', value)}
          editable={!loading}
        />

        <TextInput
          style={styles.input}
          placeholder="Teléfono"
          value={formData.telefono}
          onChangeText={(value) => updateFormData('telefono', value)}
          keyboardType="phone-pad"
          editable={!loading}
        />

        <TextInput
          style={styles.input}
          placeholder="Dirección"
          value={formData.direccion}
          onChangeText={(value) => updateFormData('direccion', value)}
          editable={!loading}
        />
        
        <TextInput
          style={styles.input}
          placeholder="Contraseña * (mínimo 6 caracteres)"
          value={formData.password}
          onChangeText={(value) => updateFormData('password', value)}
          secureTextEntry
          editable={!loading}
        />
        
        <TextInput
          style={styles.input}
          placeholder="Confirmar contraseña *"
          value={formData.confirmPassword}
          onChangeText={(value) => updateFormData('confirmPassword', value)}
          secureTextEntry
          editable={!loading}
        />
        
        <TouchableOpacity 
          style={[styles.button, loading && styles.buttonDisabled]} 
          onPress={handleRegister}
          disabled={loading}
        >
          {loading ? (
            <ActivityIndicator color="white" />
          ) : (
            <Text style={styles.buttonText}>Registrarse</Text>
          )}
        </TouchableOpacity>

        <TouchableOpacity 
          style={styles.loginButton}
          onPress={() => router.push("/login" as any)}
          disabled={loading}
        >
          <Text style={styles.loginText}>¿Ya tienes cuenta? Inicia sesión</Text>
        </TouchableOpacity>

        <Text style={styles.note}>
          Nota: Esta aplicación de demostración simula el registro. En producción, necesitarías permisos de administrador en Keycloak.
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  content: {
    padding: 20,
    paddingTop: 40,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 8,
    color: '#333',
  },
  subtitle: {
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 10,
    color: '#666',
  },
  requiredNote: {
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 20,
    color: '#FF3B30',
    fontStyle: 'italic',
  },
  input: {
    backgroundColor: 'white',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#ddd',
    fontSize: 16,
  },
  button: {
    backgroundColor: '#34C759',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 8,
    marginBottom: 20,
  },
  buttonDisabled: {
    backgroundColor: '#ccc',
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  loginButton: {
    alignItems: 'center',
    padding: 12,
    marginBottom: 20,
  },
  loginText: {
    color: '#007AFF',
    fontSize: 15,
    fontWeight: '500',
  },
  note: {
    fontSize: 12,
    color: '#888',
    textAlign: 'center',
    lineHeight: 16,
    fontStyle: 'italic',
    marginTop: 10,
  },
});